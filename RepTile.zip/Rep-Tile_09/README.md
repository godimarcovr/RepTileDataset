# Rep-Tile dataset (v0.9)

by Francesco Setti, Davide Conigliaro, Michele Tobanelli and Marco Cristani


## Content of the folder

This dataset contains 2 folders:
- **images**: all the images in .jpg format named XXX.jpg
- **annotations**: each XXX.mat file contains the annotation for the related image. Each .mat file contains one single variable named *BB* (bounding boxes); this is a cell array, where each item is a different objects class. For each class, bounding boxes are provided with the standard [x,y,w,h] notation.

This dataset is publicly available at:  http://vips.sci.univr.it/dataset/counting/data/RepTile.zip


## License

Rep-Tile is released under the MIT License (refer to the LICENSE file for details).


## Citing Rep-Tile

If you find the Rep-Tile dataset useful in your research, please consider citing:

    @article{setti2017reptile,
        title={Count on me: learning to count on a single image},
        author={Setti, Francesco and Conigliaro, Davide and Tobanelli, Michele and Cristani, Marco},
        journal={IEEE Transactions on Circuits and Systems for Video Technology},
        year={2017},
        volume={PP},
        number={99},
        doi={10.1109/TCSVT.2017.2656718},
    }


## Contacts

For any problem by using this dataset, please send an email to <francesco.setti@univr.it> .
